
from __future__ import annotations

import io
import math
import sqlite3
import json
from pathlib import Path
from typing import Any

import pandas as pd
from fastapi import FastAPI, File, UploadFile, Form, Request
from fastapi.responses import HTMLResponse, StreamingResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / "data" / "gw_express.db"

ORIGIN_LAT = -10.911148
ORIGIN_LON = -37.059038
ORIGIN_NAME = "GW Express - Rua Desembargador Enock Santiago, 91 - Aracaju/SE"

PALETTE = [
    "#e6194B", "#4363d8", "#3cb44b", "#f58231", "#911eb4", "#46f0f0",
    "#f032e6", "#bcf60c", "#fabebe", "#008080", "#e6beff", "#9a6324",
    "#fffac8", "#800000", "#aaffc3", "#808000", "#ffd8b1", "#000075",
    "#808080", "#000000", "#ffe119", "#bfef45", "#42d4f4", "#dcbeff",
]

app = FastAPI(title="GW Express Roteirizador")
app.mount("/static", StaticFiles(directory=ROOT / "app" / "static"), name="static")
templates = Jinja2Templates(directory=ROOT / "app" / "templates")


def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    DB_PATH.parent.mkdir(exist_ok=True)
    with db() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                raw_json TEXT,
                route_json TEXT,
                summary_json TEXT,
                invalid_json TEXT,
                removed_json TEXT DEFAULT '[]',
                config_json TEXT
            )
            """
        )


init_db()


def to_float(v: Any) -> float | None:
    if v is None:
        return None
    try:
        if isinstance(v, str):
            v = v.replace(",", ".").strip()
        if v == "":
            return None
        return float(v)
    except Exception:
        return None


def haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0
    p1 = math.radians(lat1)
    p2 = math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return r * 2 * math.asin(math.sqrt(a))


def clean_spr(v: Any) -> str:
    s = str(v or "").strip()
    s = s.replace("SPR", "").replace("spr", "").strip()
    return s or "GERAL"


def nearest_order(rows: list[dict], lat_col: str, lon_col: str) -> list[dict]:
    remaining = rows[:]
    ordered: list[dict] = []
    cur_lat, cur_lon = ORIGIN_LAT, ORIGIN_LON
    while remaining:
        best_i = 0
        best_d = float("inf")
        for i, r in enumerate(remaining):
            lat, lon = to_float(r.get(lat_col)), to_float(r.get(lon_col))
            if lat is None or lon is None:
                d = float("inf")
            else:
                d = haversine(cur_lat, cur_lon, lat, lon)
            if d < best_d:
                best_i, best_d = i, d
        picked = remaining.pop(best_i)
        ordered.append(picked)
        lat, lon = to_float(picked.get(lat_col)), to_float(picked.get(lon_col))
        if lat is not None and lon is not None:
            cur_lat, cur_lon = lat, lon
    return ordered


def route_km(rows: list[dict], lat_col: str, lon_col: str) -> float:
    if not rows:
        return 0.0
    km = 0.0
    cur_lat, cur_lon = ORIGIN_LAT, ORIGIN_LON
    for r in rows:
        lat, lon = to_float(r.get(lat_col)), to_float(r.get(lon_col))
        if lat is None or lon is None:
            continue
        km += haversine(cur_lat, cur_lon, lat, lon)
        cur_lat, cur_lon = lat, lon
    km += haversine(cur_lat, cur_lon, ORIGIN_LAT, ORIGIN_LON)
    return km


def split_feasible(rows: list[dict], cap_max: int, km_max: float, lat_col: str, lon_col: str) -> list[list[dict]]:
    rows = nearest_order(rows, lat_col, lon_col)
    groups: list[list[dict]] = []
    current: list[dict] = []
    for r in rows:
        test = nearest_order(current + [r], lat_col, lon_col)
        if current and (len(test) > cap_max or route_km(test, lat_col, lon_col) > km_max):
            groups.append(nearest_order(current, lat_col, lon_col))
            current = [r]
        else:
            current = test
    if current:
        groups.append(nearest_order(current, lat_col, lon_col))
    return groups


def center(rows: list[dict], lat_col: str, lon_col: str) -> tuple[float, float]:
    vals = [(to_float(r.get(lat_col)), to_float(r.get(lon_col))) for r in rows]
    vals = [(a, b) for a, b in vals if a is not None and b is not None]
    if not vals:
        return ORIGIN_LAT, ORIGIN_LON
    return sum(a for a, _ in vals) / len(vals), sum(b for _, b in vals) / len(vals)


def merge_low_ado(groups: list[list[dict]], cap_min: int, cap_max: int, km_max: float, lat_col: str, lon_col: str) -> list[list[dict]]:
    changed = True
    while changed:
        changed = False
        groups = sorted(groups, key=len)
        for i, small in enumerate(groups):
            if len(small) >= cap_min:
                continue
            best_j = None
            best_d = float("inf")
            best_group = None
            c1 = center(small, lat_col, lon_col)
            for j, g in enumerate(groups):
                if i == j:
                    continue
                merged = nearest_order(g + small, lat_col, lon_col)
                if len(merged) > cap_max:
                    continue
                if route_km(merged, lat_col, lon_col) > km_max:
                    continue
                c2 = center(g, lat_col, lon_col)
                d = haversine(c1[0], c1[1], c2[0], c2[1])
                if d < best_d:
                    best_j, best_d, best_group = j, d, merged
            if best_j is not None and best_group is not None:
                groups[best_j] = best_group
                groups.pop(i)
                changed = True
                break
    return groups


def maps_link(rows: list[dict], lat_col: str, lon_col: str) -> str:
    coords = [f"{ORIGIN_LAT},{ORIGIN_LON}"]
    for r in rows:
        lat, lon = to_float(r.get(lat_col)), to_float(r.get(lon_col))
        if lat is not None and lon is not None:
            coords.append(f"{lat},{lon}")
    return "https://www.google.com/maps/dir/" + "/".join(coords)


def cluster_bairro(rows: list[dict], bairro_col: str | None, lat_col: str, lon_col: str, radius_km: float) -> list[dict]:
    for r in rows:
        bairro = str(r.get(bairro_col, "") if bairro_col else "").strip().upper()
        if not bairro:
            bairro = "SEM_BAIRRO"
        r["CLUSTER_BAIRRO"] = bairro
    return rows


def route_engine(rows: list[dict], config: dict) -> tuple[list[dict], list[dict], list[dict]]:
    lat_col = config["lat_col"]
    lon_col = config["lon_col"]
    spr_col = config.get("spr_col") or ""
    bairro_col = config.get("bairro_col") or ""
    cap_max = int(config.get("cap_max", 95))
    cap_min = int(config.get("cap_min", 70))
    km_max = float(config.get("km_max", 35))
    cluster_radius = float(config.get("cluster_radius", 3))

    valid_rows: list[dict] = []
    for idx, r in enumerate(rows, start=1):
        r = dict(r)
        r["ID_ROTA"] = r.get("ID_ROTA") or idx
        lat, lon = to_float(r.get(lat_col)), to_float(r.get(lon_col))
        if lat is None or lon is None:
            r["MOTIVO_INVALIDO"] = "Coordenada inválida"
            continue
        r["SPR_PLANEJADO"] = clean_spr(r.get(spr_col)) if spr_col else "GERAL"
        valid_rows.append(r)

    valid_rows = cluster_bairro(valid_rows, bairro_col, lat_col, lon_col, cluster_radius)

    by_spr: dict[str, list[dict]] = {}
    for r in valid_rows:
        key = r["SPR_PLANEJADO"]
        by_spr.setdefault(key, []).append(r)

    route_rows: list[dict] = []
    invalid_rows: list[dict] = []
    color_idx = 0

    for spr, spr_rows in sorted(by_spr.items(), key=lambda x: x[0]):
        ordered = nearest_order(spr_rows, lat_col, lon_col)
        groups = split_feasible(ordered, cap_max, km_max, lat_col, lon_col)
        groups = merge_low_ado(groups, cap_min, cap_max, km_max, lat_col, lon_col)

        for g_idx, group in enumerate(groups, start=1):
            group = nearest_order(group, lat_col, lon_col)
            km = route_km(group, lat_col, lon_col)
            is_valid = len(group) >= cap_min and len(group) <= cap_max and km <= km_max
            route_name = f"{spr}.{g_idx}" if is_valid else f"NAO_VIAVEL_{spr}.{g_idx}"
            color = PALETTE[color_idx % len(PALETTE)] if is_valid else "#ff0000"
            if is_valid:
                color_idx += 1

            cur_lat, cur_lon = ORIGIN_LAT, ORIGIN_LON
            km_acum = 0.0
            for seq, r in enumerate(group, start=1):
                lat, lon = to_float(r.get(lat_col)), to_float(r.get(lon_col))
                trecho = haversine(cur_lat, cur_lon, lat, lon)
                km_acum += trecho
                out = dict(r)
                out.update(
                    SPR_FINAL=route_name,
                    SEQ_SPR=seq,
                    COR_SPR=color,
                    KM_TRECHO_ESTIMADO=round(trecho, 2),
                    KM_ACUMULADO_ESTIMADO=round(km_acum, 2),
                    KM_TOTAL_ROTA_ESTIMADO=round(km, 2),
                    QTD_PEDIDOS_ROTA=len(group),
                    CAPACIDADE_MAXIMA=cap_max,
                    CAPACIDADE_MINIMA=cap_min,
                    KM_MAXIMO=km_max,
                    STATUS="VALIDO PARA ENTREGA" if is_valid else "NAO VIAVEL",
                    LINK_PEDIDO_MAPS=f"https://www.google.com/maps?q={lat},{lon}",
                    LINK_ROTA_MAPS=maps_link(group, lat_col, lon_col),
                )
                if is_valid:
                    route_rows.append(out)
                else:
                    invalid_rows.append(out)
                cur_lat, cur_lon = lat, lon

    summary: list[dict] = []
    for route in sorted(set(r["SPR_FINAL"] for r in route_rows)):
        g = [r for r in route_rows if r["SPR_FINAL"] == route]
        summary.append(
            {
                "SPR": route,
                "SPR_PLANEJADO": route.split(".")[0],
                "QTD_PEDIDOS": len(g),
                "KM_ROTA_ESTIMADO": g[0]["KM_TOTAL_ROTA_ESTIMADO"] if g else 0,
                "CAPACIDADE_MINIMA": cap_min,
                "CAPACIDADE_MAXIMA": cap_max,
                "KM_MAXIMO": km_max,
                "OCUPACAO": f"{round((len(g)/cap_max)*100)}%",
                "STATUS": "VALIDO PARA ENTREGA",
                "COR": g[0]["COR_SPR"] if g else "",
                "LINK_GOOGLE_MAPS": g[0]["LINK_ROTA_MAPS"] if g else "",
            }
        )

    return route_rows, summary, invalid_rows


@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/api/upload")
async def upload(
    file: UploadFile = File(...),
    lat_col: str = Form(...),
    lon_col: str = Form(...),
    spr_col: str = Form(""),
    bairro_col: str = Form(""),
    cap_max: int = Form(95),
    cap_min: int = Form(70),
    km_max: float = Form(35),
    cluster_radius: float = Form(3),
):
    content = await file.read()
    name = file.filename or "arquivo"
    if name.lower().endswith(".csv"):
        df = pd.read_csv(io.BytesIO(content))
    else:
        df = pd.read_excel(io.BytesIO(content))
    df = df.fillna("")
    rows = df.to_dict(orient="records")
    config = dict(
        lat_col=lat_col,
        lon_col=lon_col,
        spr_col=spr_col,
        bairro_col=bairro_col,
        cap_max=cap_max,
        cap_min=cap_min,
        km_max=km_max,
        cluster_radius=cluster_radius,
    )
    route_rows, summary, invalid = route_engine(rows, config)
    with db() as conn:
        cur = conn.execute(
            "INSERT INTO jobs (name, raw_json, route_json, summary_json, invalid_json, config_json) VALUES (?, ?, ?, ?, ?, ?)",
            (name, json.dumps(rows, ensure_ascii=False), json.dumps(route_rows, ensure_ascii=False),
             json.dumps(summary, ensure_ascii=False), json.dumps(invalid, ensure_ascii=False), json.dumps(config, ensure_ascii=False)),
        )
        job_id = cur.lastrowid
    return {"job_id": job_id, "summary": summary, "invalid_count": len(invalid), "route_count": len(summary)}


@app.get("/api/job/{job_id}")
def get_job(job_id: int):
    with db() as conn:
        row = conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
    if not row:
        return JSONResponse({"error": "Job não encontrado"}, status_code=404)
    return {
        "id": row["id"],
        "name": row["name"],
        "routes": json.loads(row["route_json"] or "[]"),
        "summary": json.loads(row["summary_json"] or "[]"),
        "invalid": json.loads(row["invalid_json"] or "[]"),
        "removed": json.loads(row["removed_json"] or "[]"),
        "config": json.loads(row["config_json"] or "{}"),
    }


@app.post("/api/job/{job_id}/remove")
async def remove_point(job_id: int, payload: dict):
    point_id = str(payload.get("id"))
    with db() as conn:
        row = conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        if not row:
            return JSONResponse({"error": "Job não encontrado"}, status_code=404)
        routes = json.loads(row["route_json"] or "[]")
        removed = json.loads(row["removed_json"] or "[]")
        keep = []
        for r in routes:
            rid = str(r.get("ID_ROTA") or r.get("LINHA_ORIGINAL") or "")
            if rid == point_id:
                r["REMOVIDO_ROTA"] = "SIM"
                removed.append(r)
            else:
                keep.append(r)
        conn.execute("UPDATE jobs SET route_json=?, removed_json=? WHERE id=?", (json.dumps(keep, ensure_ascii=False), json.dumps(removed, ensure_ascii=False), job_id))
    return {"ok": True}


@app.get("/api/job/{job_id}/export.csv")
def export_csv(job_id: int):
    with db() as conn:
        row = conn.execute("SELECT route_json FROM jobs WHERE id=?", (job_id,)).fetchone()
    data = json.loads(row["route_json"] or "[]") if row else []
    df = pd.DataFrame(data)
    buf = io.StringIO()
    df.to_csv(buf, index=False, sep=";")
    return StreamingResponse(iter([buf.getvalue()]), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=gw_express_rotas.csv"})
