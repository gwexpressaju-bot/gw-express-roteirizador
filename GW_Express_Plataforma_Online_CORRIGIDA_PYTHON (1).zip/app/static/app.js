
let currentJob=null;
let routes=[], summary=[], invalid=[];
const map=L.map("map").setView([-10.911148,-37.059038],11);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19}).addTo(map);
let layer=L.layerGroup().addTo(map);

document.getElementById("uploadForm").addEventListener("submit",async e=>{
  e.preventDefault();
  const fd=new FormData(e.target);
  fd.set("file",document.getElementById("file").files[0]);
  statusMsg("Processando roteirização...");
  const res=await fetch("/api/upload",{method:"POST",body:fd});
  const data=await res.json();
  if(!res.ok){statusMsg("Erro: "+JSON.stringify(data));return;}
  currentJob=data.job_id;
  await loadJob();
});

function statusMsg(t){document.getElementById("status").textContent=t}

async function loadJob(){
  const res=await fetch(`/api/job/${currentJob}`);
  const data=await res.json();
  routes=data.routes; summary=data.summary; invalid=data.invalid;
  renderAll();
  statusMsg(`Roteirização gerada. Rotas válidas: ${summary.length}. Não viáveis: ${invalid.length}.`);
}

function renderAll(){
  document.getElementById("mPedidos").textContent=routes.length;
  document.getElementById("mRotas").textContent=summary.length;
  document.getElementById("mInvalid").textContent=invalid.length;
  const cap=Number(summary[0]?.CAPACIDADE_MAXIMA||summary[0]?.CAPACIDADE||95);
  document.getElementById("mDrivers").textContent=Math.ceil(routes.length/cap)||0;
  const km=summary.reduce((s,r)=>s+Number(r.KM_ROTA_ESTIMADO||0),0);
  document.getElementById("mKm").textContent=km.toFixed(1);
  document.getElementById("mOcupacao").textContent=summary.length?Math.round((routes.length/(summary.length*cap))*100)+"%":"0%";
  table("summaryTable",summary,true);
  table("routesTable",routes,true);
  table("invalidTable",invalid,true);
  renderMap();
  renderRomaneio();
}

function table(id,data,links){
  const el=document.getElementById(id);
  if(!data.length){el.innerHTML="<tr><td>Sem dados</td></tr>";return;}
  const cols=Object.keys(data[0]);
  let h="<thead><tr>"+cols.map(c=>`<th>${c}</th>`).join("")+"</tr></thead><tbody>";
  data.forEach(r=>{
    h+="<tr>"+cols.map(c=>{
      const v=r[c]??"";
      if(links&&String(v).startsWith("https://")) return `<td><a href="${v}" target="_blank">Abrir</a></td>`;
      if(c==="COR"||c==="COR_SPR") return `<td><span style="display:inline-block;width:16px;height:16px;border-radius:50%;background:${v}"></span></td>`;
      return `<td>${v}</td>`;
    }).join("")+"</tr>";
  });
  h+="</tbody>"; el.innerHTML=h;
}

function renderMap(){
  layer.clearLayers();
  const bounds=[];
  summary.forEach(s=>{
    const rs=routes.filter(r=>r.SPR_FINAL===s.SPR).sort((a,b)=>Number(a.SEQ_SPR)-Number(b.SEQ_SPR));
    const pts=[[-10.911148,-37.059038]];
    rs.forEach(r=>{
      const lat=Number(String(r[Object.keys(r).find(k=>k.toLowerCase().includes("latitude"))]||"").replace(",","."));
      const lon=Number(String(r[Object.keys(r).find(k=>k.toLowerCase().includes("longitude"))]||"").replace(",","."));
      if(!isNaN(lat)&&!isNaN(lon)){
        pts.push([lat,lon]); bounds.push([lat,lon]);
        const m=L.circleMarker([lat,lon],{radius:7,color:r.COR_SPR,fillColor:r.COR_SPR,fillOpacity:.9}).addTo(layer);
        m.bindPopup(`<b>${r.SPR_FINAL}</b><br>Seq ${r.SEQ_SPR}<br><button onclick="removePoint('${r.ID_ROTA}')">Retirar endereço</button>`);
      }
    });
    L.polyline(pts,{color:s.COR||rs[0]?.COR_SPR||"#000",weight:4}).addTo(layer).bindPopup(`<b>${s.SPR}</b><br><a href="${s.LINK_GOOGLE_MAPS}" target="_blank">Google Maps</a>`);
  });
  if(bounds.length) map.fitBounds(bounds,{padding:[30,30]});
}

async function removePoint(id){
  if(!confirm("Retirar este endereço?"))return;
  await fetch(`/api/job/${currentJob}/remove`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id})});
  await loadJob();
}

function showTab(id){
  document.querySelectorAll(".tab").forEach(t=>t.classList.add("hidden"));
  document.getElementById(id).classList.remove("hidden");
}

function exportCsv(){
  if(currentJob) window.open(`/api/job/${currentJob}/export.csv`,"_blank");
}

function renderRomaneio(){
  const area=document.getElementById("romaneioArea");
  let h="";
  summary.forEach(s=>{
    const rs=routes.filter(r=>r.SPR_FINAL===s.SPR).sort((a,b)=>Number(a.SEQ_SPR)-Number(b.SEQ_SPR));
    h+=`<div style="page-break-after:always"><h2>GW Express - Romaneio ${s.SPR}</h2><p>Pedidos: ${s.QTD_PEDIDOS} | KM: ${s.KM_ROTA_ESTIMADO} | Status: ${s.STATUS}</p><table><thead><tr><th>Seq</th><th>Pedido</th><th>Endereço</th><th>Status</th><th>Assinatura</th></tr></thead><tbody>`;
    rs.forEach(r=>{
      const pedido=r["Waybill No"]||r["Tracking Number"]||r.ID_ROTA||"";
      const end=r["Consignee Address"]||r.Address||r["Endereço"]||"";
      h+=`<tr><td>${r.SEQ_SPR}</td><td>${pedido}</td><td>${end}</td><td></td><td></td></tr>`;
    });
    h+="</tbody></table></div>";
  });
  area.innerHTML=h;
}
function printRomaneio(){window.print();}
